import random
import websockets
import asyncio
import json
from jmetal.core.solution import (CompositeSolution,FloatSolution,IntegerSolution,)
from optimizer import Optimizer
from client_ws import WsClient

async def handler(websocket):
    while True:
        try:
            data = await websocket.recv()
        except websockets.ConnectionClosedOK:
            break
        print(data)
        await websocket.send(str(resolve(data)))


def resolve(data):
    parsed_data = json.loads(data)
    action = parsed_data["action"]
    message = parsed_data["message"]

    if action == "optimize":
        print("entre")
        int_lower_bound = message["int"]["lower_bound"]
        int_upper_bound = message["int"]["upper_bound"]
        float_lower_bound = message["float"]["lower_bound"]
        float_upper_bound = message["float"]["upper_bound"]
        max_evaluations = message["max_evaluations"]

        integer_solution = IntegerSolution(
            int_lower_bound, int_upper_bound, 1, 0
        )
        float_solution = FloatSolution(
            float_lower_bound, float_upper_bound, 1, 0
        )

        float_solution.variables = [
            random.uniform(float_lower_bound[i] * 1.0, float_upper_bound[i] * 1.0)
            for i in range(len(float_lower_bound))
        ]
        integer_solution.variables = [
            random.uniform(int_lower_bound[i], int_upper_bound[i])
            for i in range(len(int_lower_bound))
        ]

        cs= CompositeSolution([integer_solution, float_solution])

        ws = WsClient("ws://localhost:8000")
        objetives=eval(ws.send_data(cs.variables))

        return
       
async def main():
    async with websockets.serve(handler, "localhost", 8001):
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())